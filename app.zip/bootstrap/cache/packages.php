<?php

return [
    'laravel/boost' => [
        'providers' => [
            0 => 'Laravel\\Boost\\BoostServiceProvider',
        ],
    ],
    'laravel/mcp' => [
        'aliases' => [
            'Mcp' => 'Laravel\\Mcp\\Facades\\Mcp',
        ],
        'providers' => [
            0 => 'Laravel\\Mcp\\Server\\McpServiceProvider',
        ],
    ],
    'laravel/pail' => [
        'providers' => [
            0 => 'Laravel\\Pail\\PailServiceProvider',
        ],
    ],
    'laravel/pao' => [
        'providers' => [
            0 => 'Laravel\\Pao\\Laravel\\ServiceProvider',
        ],
    ],
    'laravel/roster' => [
        'providers' => [
            0 => 'Laravel\\Roster\\RosterServiceProvider',
        ],
    ],
    'laravel/sanctum' => [
        'providers' => [
            0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
        ],
    ],
    'laravel/tinker' => [
        'providers' => [
            0 => 'Laravel\\Tinker\\TinkerServiceProvider',
        ],
    ],
    'nesbot/carbon' => [
        'providers' => [
            0 => 'Carbon\\Laravel\\ServiceProvider',
        ],
    ],
    'nunomaduro/collision' => [
        'providers' => [
            0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
        ],
    ],
    'nunomaduro/termwind' => [
        'providers' => [
            0 => 'Termwind\\Laravel\\TermwindServiceProvider',
        ],
    ],
    'pestphp/pest-plugin-laravel' => [
        'providers' => [
            0 => 'Pest\\Laravel\\PestServiceProvider',
        ],
    ],
];
