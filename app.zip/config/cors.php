<?php

$normalizeOrigin = static fn (?string $origin): ?string => $origin !== null && $origin !== ''
    ? rtrim($origin, '/')
    : null;

return [

    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => array_values(array_filter(array_unique(array_map(
        $normalizeOrigin,
        [
            env('FRONTEND_URL', 'http://localhost:8443'),
            'http://127.0.0.1:8443',
            'https://lookuppostcode.com',
            'https://www.lookuppostcode.com',
        ],
    )))),

    'allowed_origins_patterns' => [
        '#^https://([a-z0-9-]+\.)?lookuppostcode\.com$#',
    ],

    'allowed_headers' => [
        'Accept',
        'Authorization',
        'Content-Type',
        'X-Requested-With',
        'X-Organisation-Id',
        'X-Environment',
    ],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => false,

];
