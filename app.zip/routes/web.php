<?php

use App\Http\Controllers\LotPaymentWebCallbackController;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::match(['get', 'post'], '/payment/lotpayment/callback', LotPaymentWebCallbackController::class)
    ->name('payment.lotpayment.callback');

Route::get('/trustscoring-api/{path}', function (string $path) {
    $query = request()->getQueryString();
    $url = 'https://api.trustscoring.com/api/'.ltrim($path, '/');
    if ($query) {
        $url .= '?'.$query;
    }

    $upstream = Http::timeout(15)->acceptJson()->get($url);

    return response($upstream->body(), $upstream->status())
        ->header('Content-Type', $upstream->header('Content-Type') ?: 'application/json');
})->where('path', '.*');